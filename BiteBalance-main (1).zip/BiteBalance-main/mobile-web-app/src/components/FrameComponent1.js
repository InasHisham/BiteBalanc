import "./FrameComponent1.css";

const FrameComponent1 = () => {
  return (
    <div className="recipie-child">
      <div className="frame-item" />
    </div>
  );
};

export default FrameComponent1;
