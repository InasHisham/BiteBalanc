import "./FrameComponent9.css";

const FrameComponent9 = () => {
  return (
    <header className="recipie-inner">
      <div className="image-35-parent">
        <button className="image-35" />
        <input
          className="search-recipes"
          placeholder="Search recipes...."
          type="search"
        />
      </div>
    </header>
  );
};

export default FrameComponent9;
