import "./FrameComponent5.css";

const FrameComponent5 = () => {
  return (
    <nav className="name-parent">
      <div className="name1">Name</div>
      <div className="age1">Age</div>
      <div className="date-of-birth">Date of Birth</div>
      <div className="weight">Weight</div>
      <div className="height">Height</div>
      <div className="gender1">Gender</div>
      <div className="email1">Email</div>
    </nav>
  );
};

export default FrameComponent5;
